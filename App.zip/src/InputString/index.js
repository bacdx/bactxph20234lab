import { Text,StyleSheet,TextInput,Button,Modal, View } from "react-native";

export default function BoxInput(props){
    const name=props.name;
    const moTa=props.moTa;
   
    return(<View
    style={styles.modalView}><Modal 
      // visible='fasle'
    >
    <TextInput defaultValue="Name"
    style={styles.input}
    ></TextInput>
     <TextInput defaultValue="Mo Ta"
    style={styles.input}
    ></TextInput>
     <TextInput defaultValue="Link"
    style={styles.input}
    ></TextInput>
    <>
    <Button title="huy"
    onPress={()=>{}}
    ></Button>
    <Button title="Luu"
    ></Button>
    </>
    </Modal>
    </View>)
    
}
const styles = StyleSheet.create({
    input: {
        width:200,
      height: 40,
      margin: 12,
      borderWidth: 1,
      padding: 10,
    },
    modalView: {
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    }
    
  });