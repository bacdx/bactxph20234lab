import{Text,Image,StyleSheet}from'react-native';
// trong 1 file cho chua q function dc export dangj defaut
// Neu export default thi khi export ko can {}
export function ProductImage(props){
    
    return(<Image 
        style={style.image}
    source={'https://www.bing.com/images/search?view=detailV2&ccid=m94WGQGc&id=0C24D9458E29AAC719DB0B2C0C3272EE5C18C5A9&thid=OIP.m94WGQGcUBt81SP157qugAHaDF&mediaurl=https%3a%2f%2fuploads-ssl.webflow.com%2f5e96913c9bac7c0b5cb3391c%2f5f44a7398c0cdf460857e744_img-image.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.9bde1619019c501b7cd523f5e7baae80%3frik%3dqcUYXO5yMgwsCw%26pid%3dImgRaw%26r%3d0&exph=668&expw=1600&q=img&simid=608030982824999073&FORM=IRPRST&ck=598FAABE559ACFA5A50D7E679D0430DE&selectedIndex=1'}>

    </Image>
    )
}
export default function ProductText(props){
      //props la 1 obj truyen tu cha sang con
                //o day co 1 key la name
                const name=props.name;
               const desc= props.desc;
               
    return(
        <>
        <Text style={style.text}>{name}</Text>
        <Text>{desc?desc:'Updating'}</Text>
        </>
    );
}


const style=StyleSheet.create({
    text:{
        fontSize:30,
        fontStyle:"italic",
        color:'blue'
    },

    image:{
        width:200,
        height:200
    }
});