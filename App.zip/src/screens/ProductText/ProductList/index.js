import { Text, FlatList,StyleSheet,SafeAreaView} from "react-native";
import { ProductImage } from "..";

export default function ProductList(props){

    // const productlist=[
    //     {
    //         id:1,
    //          name:'Tran Xuan Bac ',
    //          description:100000},

    //         {
    //          id:2,
    //          name:'Tran Xuan Bac ',
    //          description:150000
    //         }
             
        
    // ];
    const productlist=props.productlist;
    return(
        <FlatList
        data={productlist}
         renderItem={({item})=>(
            <SafeAreaView style={style.box} >
            
            <Text>Name:{item.name}</Text>
            <Text>Mo Ta:{item.description}</Text>
            </SafeAreaView>
         )}
         keyExtractor={(item)=>item.id}>

         </FlatList>
    )
}

const style=StyleSheet.create({
box:{
width:300,
borderBottomWidth:1,
borderStyle:"solid",

}
})