import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, View,TextInput, Modal, Pressable } from 'react-native';
import { useState } from 'react';
import ProductText ,{ProductImage as PI}  from './src/screens/ProductText';
import ProductList from './src/screens/ProductText/ProductList';
import BoxInput from './src/InputString';
// goi duoi 1 cai ten khac la PI

export default function App() {
  const[countState,setCountState]=useState(0);
  const[showStatus,setShowStatus]=useState(true);
  const[modalVisible,setModalVisible]=useState(false);
  let name="Bac";
  let age=20;
      const productlist=[
        {
            id:1,
             name:'Tran Xuan Bac ',
             description:100000},

            {
             id:2,
             name:'Tran Xuan Bac ',
             description:150000
            }
             
        
    ];
  if(age>20){
    name="Tran Xuan Bac-nguoi lon";
  }else{
    name="Tran Xuan Bac-Tre em";
  }
  
function ShowData(label="",value=""){
 
}
//arrow function
const arrowShowData=(label="",value="")=> {return   label+': '+value;};

const arrowMiniShowData=(label="",value="")=> label+': '+value;//co the viet nhu nay (label+': '+value;)

let count=0;
const tangCount=(count)=>count++;
  return (
    <View style={styles.container}>
      <Text>Ho Ten:Tran Xuan Bac</Text>
      <Text>MSV: PH20234</Text>
      <StatusBar style='auto'></StatusBar>
      <Button
      title='add'
      onPress={()=>setModalVisible(!modalVisible)}
      ></Button>
  
     <ProductList productlist={productlist}></ProductList>
     <Modal transparent={true} visible={modalVisible}>
     <View style={styles.centeredView}>
      <View style={styles.modalView}>
      
        <TextInput style={styles.inputText}
        placeholder="Name"></TextInput>
        <TextInput style={styles.inputText}
        placeholder="Mo Ta"></TextInput>
        <TextInput style={styles.inputText}
        placeholder="Link"
        ></TextInput>
       
      <View style={styles.row}>
      <Pressable style={[styles.button,styles.buttonClose]}
      onPress={()=>setModalVisible(!modalVisible)}><Text>Close</Text></Pressable>
      <Pressable style={[styles.button,styles.buttonClose]}
      onPress={()=>setModalVisible(!modalVisible)}><Text>Add</Text></Pressable>
      </View>
      
      </View>
      
     </View>
     </Modal>
      {/* <Button 
      title={'Bam de tang Count'}
      onPress={()=>tangCount()}/>

      <Text style={styles.text}>{countState} PH20234</Text>
      <Button 
      title={'Bam de tang Count'}
      onPress={()=>setCountState(countState+1)}/>
      <Button style={styles.text}
      title={"Show"}
      onPress={()=>setShowStatus(!showStatus)}/>
      {
        showStatus?
        <>
        <Text style={styles.text}>{name} PH20234</Text>
        <Text style={styles.text}>{ShowData("Email","bactxph20234")}</Text>
        <Text style={styles.text}>{ShowData("SDT","0359789536")}</Text>
        <Text style={styles.text}>{arrowShowData("Email","bactxph20234")}</Text>
        <Text style={styles.text}>{arrowMiniShowData("SDT","0359789536")}</Text>
        <Text style={styles.text}>{count} PH20234</Text></>
        :null
      }
      <ProductText name={'ten SP1'} desc={'123'} />
      <ProductText name={'ten SP2'}  desc={'123'} />
      <ProductText name={'ten S3'}  desc={'123'} /> */}
      
      {/* <ProductList productlist = {productlist}>
       
      </ProductList> */}
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop:100,
    // flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    container:"20px"
  },
  text:{
    color:"red"
    
    
    // alt+shift+Xuong:sao chep dong tren
    // ctrl+D boi vao sua cho giong nhau
    // ctrl+x khong boi den xoa ca dong
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
   
  },
  modalView: {
    width: 300,
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    margin:20,
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  inputText:{
    margin:10,
    width:200,
    borderWidth:1,
    paddingLeft:20
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
});
